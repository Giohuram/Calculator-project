# Lesson plan
  ## Tasks
  1. liste fonctions
     * UI: numpad, operations, displays, clear, annuler, second display to show calcul en cours
     * input field accepts input from keyboard and numpad buttons
     * operations fondamentales (+, -, *, /)
     * historique: paneau a droite de la liste du plus recent au plus ancien des operations effectuees, click sur un item restore l'operation faite et sa reponses dans les displays
     * C button clears current input and removes it from both displays
     * AC button cancel the whole operation
     * 